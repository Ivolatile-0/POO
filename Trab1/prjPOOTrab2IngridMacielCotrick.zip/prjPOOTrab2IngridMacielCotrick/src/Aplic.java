import fatec.poo.model.Garcom;
import fatec.poo.model.Cliente;
import java.text.DecimalFormat;
import java.util.Scanner;

public class Aplic {
    public static void main(String[] args) {
        int codigo, numMesa;
        String nome;
        double taxaServico;
        Scanner entrada = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#,##0.00");
        
        Cliente objCli = new Cliente();
        Garcom objGar = new Garcom();
        
        System.out.println("Digite o código do cliente: ");
        codigo = entrada.nextInt();
        System.out.println("Digite o nome do cliente: ");
        nome = entrada.next();
        System.out.println("Digite o número da mesa: ");
        numMesa = entrada.nextInt();
        
        System.out.println("Digite o código do cliente: ");
        codigo = entrada.nextInt();
        System.out.println("Digite o nome do cliente: ");
        nome = entrada.next();
        System.out.println("Digite o número da mesa: ");
        numMesa = entrada.nextInt();
        
        System.out.println("Digite o código do garçom: ");
        codigo = entrada.nextInt();
        System.out.println("Digite o nome do garçom: ");
        nome = entrada.next();
        System.out.println("Digite o valor da taxa de serviço: ");
        numMesa = entrada.nextInt();
        
        System.out.println("Código do Garçom: " + objGar.getCodigo());
        System.out.println("Nome do Garçom: " + objGar.getNome());
        System.out.println("Número da Mesa: " + objCli.getNumMesa());
        System.out.println("Total da Conta: " + df.format(objCli.getTotalConta()));
        System.out.println("Número da Mesa: " + objCli.getNumMesa());
        System.out.println("Total da Conta: " + df.format(objCli.getTotalConta()));
        System.out.println("Salário: "+ df.format(objGar.calcSalarioFinal()));
    }
}
